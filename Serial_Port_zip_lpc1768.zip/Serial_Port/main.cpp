
#include "mbed.h"
#include <string>

DigitalOut myled(LED1);

Serial serial(USBTX,USBRX); //El objeto serial es el que envia la informacion.
            



int main() {
    serial.baud(9600);
    
    while(1) {
        char Datosrecibidos = serial.getc();//La variable Datos_Recibidos recibe la informacion de entrada. 
                                            //La guardaremos en un string y compararemos para evr que pasa. 
         string DatosRecibidos = " ";
         DatosRecibidos += Datosrecibidos;                                     
        
        
        for(int i = 0 ; i< 100; i++){
            serial.printf("Mensaje enviado desde mbed  %i\n",i);
            wait(1);
        
            }
        }
}
